import type { Skin } from '../skin'

const skin: Skin = {
  name: 'ultraviolet',
  label: 'Ultraviolet',
  palette: {
    read: '#c0a8ff',
    write: '#ffcdda',
    run: '#8c9eff',
    search: '#b07cff',
    web: '#f28dff',
    mcp: '#d7c9ff',
    other: '#ede6ff',
    user: '#e84bff',
    fg: '#f4eeff',
    muted: '#a397c9',
    surface: '#151c42',
    zebra: '#1a1230',
    ok: '#7fe3b4',
    err: '#ff5c8a',
    warn: '#ffd48a',
  },
  light: {
    read: '#6a4fc4',
    write: '#b0466a',
    run: '#10288c',
    search: '#7a2fd0',
    web: '#a81fbf',
    mcp: '#5a4a99',
    other: '#3d3557',
    user: '#4b0090',
    fg: '#1f1a2e',
    muted: '#665d80',
    surface: '#ffffff',
    zebra: '#f6f1ff',
    ok: '#1f7a52',
    err: '#c2184f',
    warn: '#8a5a00',
  },
  spinner: ['Glowing', 'Shimmering', 'Dreaming', 'Drifting', 'Sparkling', 'Humming'],
  done: ['Glowed', 'Dreamt', 'Lit', 'Charged'],
}

export default skin
